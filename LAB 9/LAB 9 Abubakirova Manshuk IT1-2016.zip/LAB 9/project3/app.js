// local reviews data
const reviews = [
  {
    id: 1,
    name: "Manshuk Abubakirova",
    job: "Programmer",
    img:
      "attachment.jpeg",
    text:
      "I am a second year student of IITU and I really love the pop artists that are shown on the next slides!",
  },
  {
    id: 2,
    name: "Nicki Minaj",
    job: "Rapper",
    img:
      "https://pbs.twimg.com/media/DJBFJUkXcAE5m8I.jpg",
    text:
      "Trinidadian singer, rapper, songwriter and actress. Noticed the talent of a young girl Lil Wayne, who, after hearing the mixtapes Playtime Is Over and Beam Me Up Scotty signed a contract with her on behalf of his label Young Money Entertainment in August 2009.",
  },
  {
    id: 3,
    name: "Beyonce",
    job: "Singer & dancer",
    img:
      "https://www.rollingstone.com/wp-content/uploads/2020/06/beta20-honoree-humanitarian.jpg",
    text:
      "American singer in the style of R'n'B, actress, dancer, music producer. As a child, she participated in various vocal and dance competitions, took part in school amateur performances. Knowles became famous in the late 1990s as the lead singer of the female R&B group Destiny's Child.",
  },
  {
    id: 4,
    name: "Lady Gaga",
    job: "Rock star",
    img:
      "http://ladygaga.ru/gallery/albums/appearances/2009/best-buy-11-23/g_2835729.jpg",
    text:
      "American singer, songwriter, producer, philanthropist, designer and actress. She began her career with performances in clubs, and by the end of 2007, producer Vincent Herbert signed the singer to the Streamline Records label, which is an offshoot of Interscope Records. ",
  },
];
// select items
const img = document.getElementById("person-img");
const author = document.getElementById("author");
const job = document.getElementById("job");
const info = document.getElementById("info");

const prevBtn = document.querySelector(".prev-btn");
const nextBtn = document.querySelector(".next-btn");
const randomBtn = document.querySelector(".random-btn");

// set starting item
let currentItem = 0;

// load initial item
window.addEventListener("DOMContentLoaded", function () {
  const item = reviews[currentItem];
  img.src = item.img;
  author.textContent = item.name;
  job.textContent = item.job;
  info.textContent = item.text;
});

// show person based on item
function showPerson(person) {
  const item = reviews[person];
  img.src = item.img;
  author.textContent = item.name;
  job.textContent = item.job;
  info.textContent = item.text;
}
// show next person
nextBtn.addEventListener("click", function () {
  currentItem++;
  if (currentItem > reviews.length - 1) {
    currentItem = 0;
  }
  showPerson(currentItem);
});
// show prev person
prevBtn.addEventListener("click", function () {
  currentItem--;
  if (currentItem < 0) {
    currentItem = reviews.length - 1;
  }
  showPerson(currentItem);
});
// show random person
randomBtn.addEventListener("click", function () {
  console.log("hello");

  currentItem = Math.floor(Math.random() * reviews.length);
  showPerson(currentItem);
});